/**
 * 
 */
package com.studio.domain;

/**
 * @author ezhilraja_k
 *
 */
public class OrderJson {

	private long orderId;
	private Integer noOfSheet;
	private Double balance;
	private String custName;
	private String mobileNo;
	private String status;
	/**
	 * @return the orderId
	 */
	public long getOrderId() {
		return orderId;
	}
	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}
	/**
	 * @return the noOfSheet
	 */
	public Integer getNoOfSheet() {
		return noOfSheet;
	}
	/**
	 * @param noOfSheet the noOfSheet to set
	 */
	public void setNoOfSheet(Integer noOfSheet) {
		this.noOfSheet = noOfSheet;
	}
	/**
	 * @return the balance
	 */
	public Double getBalance() {
		return balance;
	}
	/**
	 * @param balance the balance to set
	 */
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	/**
	 * @return the custName
	 */
	public String getCustName() {
		return custName;
	}
	/**
	 * @param custName the custName to set
	 */
	public void setCustName(String custName) {
		this.custName = custName;
	}
	/**
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}
	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
