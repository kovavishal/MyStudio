/**
 * 
 */
package com.studio.constants;

/**
 * @author ezhilraja_k
 *
 */
public interface Meta {

	String ORDER_TYPES ="ordertypes";
}
